export const Learnsets: {[k: string]: ModdedLearnsetData} = {
	vivillonfancy: {
		inherit: true,
		eventOnly: true,
	},
};
