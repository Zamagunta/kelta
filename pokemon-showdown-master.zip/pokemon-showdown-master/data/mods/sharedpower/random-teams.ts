import RandomTeams from '../../random-teams';

export class RandomSharedPowerTeams extends RandomTeams {}

export default RandomSharedPowerTeams;
